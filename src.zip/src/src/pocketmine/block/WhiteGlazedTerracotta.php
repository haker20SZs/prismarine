<?php

namespace pocketmine\block;

class WhiteGlazedTerracotta extends GlazedTerracotta {
	
	protected $id = self::WHITE_GLAZED_TERRACOTTA;
	
	public function getName() {
		return "White Glazed Terracotta";
	}
	
}
