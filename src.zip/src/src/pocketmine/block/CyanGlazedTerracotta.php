<?php

namespace pocketmine\block;

class CyanGlazedTerracotta extends GlazedTerracotta {
	
	protected $id = self::CYAN_GLAZED_TERRACOTTA;
	
	public function getName() {
		return "Cyan Glazed Terracotta";
	}
	
}
