<?php

namespace pocketmine\block;

class YellowGlazedTerracotta extends GlazedTerracotta {
	
	protected $id = self::YELLOW_GLAZED_TERRACOTTA;
	
	public function getName() {
		return "Yellow Glazed Terracotta";
	}
	
}
