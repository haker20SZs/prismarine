<?php

namespace pocketmine\block;

class MagentaGlazedTerracotta extends GlazedTerracotta {
	
	protected $id = self::MAGENTA_GLAZED_TERRACOTTA;
	
	public function getName() {
		return "Magenta Glazed Terracotta";
	}
	
}
