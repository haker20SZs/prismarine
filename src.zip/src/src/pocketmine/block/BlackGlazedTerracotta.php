<?php

namespace pocketmine\block;

class BlackGlazedTerracotta extends GlazedTerracotta {
	
	protected $id = self::BLACK_GLAZED_TERRACOTTA;
	
	public function getName() {
		return "Black Glazed Terracotta";
	}
	
}
