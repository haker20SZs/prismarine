<?php

namespace pocketmine\block;

class PinkGlazedTerracotta extends GlazedTerracotta {
	
	protected $id = self::PINK_GLAZED_TERRACOTTA;
	
	public function getName() {
		return "Pink Glazed Terracotta";
	}
	
}
