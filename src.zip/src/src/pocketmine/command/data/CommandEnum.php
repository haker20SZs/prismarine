<?php

declare(strict_types=1);

namespace pocketmine\command\data;

final class CommandEnum extends CommandParameter{
	public function __construct(string $name, array $enumValues, bool $optional = false, string $overload = 'default'){
		parent::__construct($name, CommandParameter::ARG_TYPE_STRING_ENUM, $optional);
		$this->enum_values = $enumValues;
		$this->overload = $overload;
	}
}